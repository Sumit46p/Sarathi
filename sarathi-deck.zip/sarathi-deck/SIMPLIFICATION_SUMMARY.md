# Sarathi Deck Simplification Summary

## Date: October 6, 2026

## Overview
Simplified the Sarathi presentation deck to remove complex mathematics, reduce technical jargon, and improve overall readability and visual clarity.

---

## Changes Made

### **Slide 2 (s02.html) - Problem Statement**
- ✅ Increased subtitle font size to 19px
- ✅ Added clarifying question: "But which one is truly closest?"
- ✅ More conversational tone

### **Slide 3 (s03.html) - Platform Overview**
- ✅ Changed subtitle to more welcoming language
- ✅ "Everything you need to manage vehicles, drivers, and dispatch operations in one integrated system"
- ✅ Font size increased to 19px for better readability

### **Slide 4 (s04.html) - System Architecture**
- ✅ Simplified technical descriptions throughout
- ✅ Replaced "PostgreSQL 16 with PostGIS stores all models..." with "Main database stores all fleet data including vehicle locations..."
- ✅ Changed "OSRMClient talks to the external OSRM server..." to "Routing Service communicates with external road network server..."
- ✅ Simplified "DispatchService filters vehicles, queries OSRM..." to "Dispatch Service finds available vehicles, calculates road routes..."
- ✅ Removed technical jargon like "JWTAuthMiddleware", "SimpleJWT", "Django Channels"
- ✅ Increased description box padding and font size (14px → 20px padding, 15px → 16px font)
- ✅ Added line-height for better readability

### **Slide 5 (s05.html) - Fleet Management**
- ✅ Subtitle: "The admin portal shows vehicles, drivers, and availability status at a glance"
- ✅ Changed "Sample data" to "Sample data shown"
- ✅ Font size increased to 19px

### **Slide 6 (s06.html) - Dispatch Engine** ⭐ **MAJOR SIMPLIFICATION**
- ✅ **Removed complex mathematical formulas entirely**
  - **BEFORE:** `S = max(5, 100 − P_ETA − P_dist) + B`
  - **AFTER:** Plain English explanation:
    - "Start with 100 points"
    - "Subtract for longer travel time"
    - "Subtract for greater distance"
    - "Add bonus for emergency (within 10 minutes)"
- ✅ Changed subtitle to "Four simple steps to pick the best vehicle"
- ✅ Improved step labels with emojis: 1️⃣ 2️⃣ 3️⃣ 4️⃣
- ✅ Steps now say: "Filter available vehicles", "Calculate road routes", "Score each vehicle", "Pick best & explain why"
- ✅ Increased font sizes (14px → 15px, 20px for titles)
- ✅ Better line spacing (line-height: 1.8, 2)

### **Slide 7 (s07.html) - Road Routing**
- ✅ **Removed "Douglas-Peucker" algorithm reference**
- ✅ Changed title from "OSRM returns dense road geometry..." to "The routing service gives us detailed road data. We simplify it to make maps load faster."
- ✅ Removed epsilon notation (ε = 0.0005°)
- ✅ Changed "tolerance" to "Detail level"
- ✅ "show raw OSRM points" → "Show all original points"
- ✅ Added section header "Routing features"
- ✅ Simplified technical terms: "continue_straight" → "System prefers direct routes without detours"
- ✅ "30 s" → "30 seconds"
- ✅ "Haversine if OSRM is down" → "Backup method if main routing service is unavailable"

### **Slide 8 (s08.html) - Dispatch Lifecycle**
- ✅ Removed code reference: `DispatchRequest.VALID_TRANSITIONS`
- ✅ Changed to: "Every dispatch request follows a clear path from creation to completion"
- ✅ Font size increased to 19px

### **Slide 9 (s09.html) - GPS Tracking**
- ✅ Removed technical jargon: "REST save and fast polling"
- ✅ Changed to: "Driver locations reach the dispatcher's map through quick updates every few seconds"
- ✅ "WebSockets carry the alerts" → "Emergency alerts use instant WebSocket notifications"
- ✅ Improved WebSocket section readability
- ✅ Font size increased to 19px

### **Slide 10 (s10.html) - Driver Workflow**
- ✅ Removed "JWT login" reference
- ✅ Changed to: "Secure login with username, organization, and password"
- ✅ Removed code: `Driver.is_on_duty` and `/api/drivers/me/`
- ✅ Changed "5 s" → "5 seconds"
- ✅ Better subtitle: "Complete driver journey from login to trip completion"
- ✅ Increased font size (15px) and line-height (1.9)

### **Slide 11 (s11.html) - Differentiation**
- ✅ Removed technical abbreviations:
  - "JWT WebSockets" → "Secure real-time updates"
  - "Two Redis tiers" → "Fast data caching"
  - "PostGIS + GIST" → "Fast location search"
  - "Multi-tenant RBAC" → "Secure multi-organization"
- ✅ "Douglas-Peucker ε 0.0005°" → "Routes simplified for faster loading without losing accuracy"
- ✅ "OSRM + Haversine fallback" → "Reliable routing with automatic backup"

---

## Design Improvements

### Typography
- Increased subtitle font sizes from 13px to 19-20px across all slides
- Added line-height for better readability (1.6-2.0)
- Increased padding in key sections

### Content Density
- Removed mathematical formulas and replaced with bullet points
- Simplified technical jargon throughout
- Used plain English instead of code references
- Added emojis for visual hierarchy (1️⃣ 2️⃣ 3️⃣ 4️⃣)

### Visual Clarity
- Increased spacing between elements
- Better use of whitespace
- Clearer section headers
- More conversational language

---

## Impact

### Before
- Complex mathematical formulas (subscripts, Greek letters)
- Heavy technical jargon (JWT, OSRM, Django, PostGIS, GIST)
- Code references throughout
- Compressed layouts
- Small fonts

### After
- Plain English explanations
- User-friendly terminology
- No code references in main content
- Better spacing and readability
- Larger, more readable fonts
- Clear visual hierarchy

---

## Result
The presentation is now:
✅ **Easier to understand** for non-technical audiences
✅ **Less crowded** with better spacing and larger fonts
✅ **More accessible** with plain language instead of mathematics
✅ **Cleaner** visual design without sacrificing technical accuracy
✅ **More engaging** with conversational tone and clear hierarchy

The presentation maintains all functionality and interactivity while being significantly more approachable for presentations to diverse audiences including clients, investors, and academic evaluators.
